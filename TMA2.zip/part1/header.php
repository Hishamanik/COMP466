<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=0.5">
	<title><?php echo $pageTitle;?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<section>
	 <div class="navigation-bar">
        <div class="navigation">
           <a href="index.php"><img  src="../images/logo.jpg" alt ="Website Logo" style= "text-align:center"></a>
            <ul>
                <li><a href="login.php">LOGIN </a></li>
                <li><a href="signup.php">SIGN UP</a></li>
            </ul>
        </div>
    </div>
</section>


